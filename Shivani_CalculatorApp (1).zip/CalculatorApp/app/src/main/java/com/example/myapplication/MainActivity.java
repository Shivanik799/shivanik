package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main); // Make sure you have an XML layout file named "activity_main.xml"
    }

    public void add(View v) {
        EditText num1 = findViewById(R.id.number1);
        int x = Integer.parseInt(num1.getText().toString());
        EditText num2 = findViewById(R.id.number2);
        int y = Integer.parseInt(num2.getText().toString());
        TextView out = findViewById(R.id.FinalOutput);
        out.setText("Addition is= " + (x + y));
    }

    public void sub(View v) {
        EditText num1 = findViewById(R.id.number1);
        int x = Integer.parseInt(num1.getText().toString());
        EditText num2 = findViewById(R.id.number2);
        int y = Integer.parseInt(num2.getText().toString());
        TextView out = findViewById(R.id.FinalOutput);
        out.setText("Subtraction is= " + (x - y));
    }

    public void mul(View v) {
        EditText num1 = findViewById(R.id.number1);
        int x = Integer.parseInt(num1.getText().toString());
        EditText num2 = findViewById(R.id.number2);
        int y = Integer.parseInt(num2.getText().toString());
        TextView out = findViewById(R.id.FinalOutput);
        out.setText("Multiplication is= " + (x * y));
    }

    public void div(View v) {
        EditText num1 = findViewById(R.id.number1);
        int x = Integer.parseInt(num1.getText().toString());
        EditText num2 = findViewById(R.id.number2);
        int y = Integer.parseInt(num2.getText().toString());
        TextView out = findViewById(R.id.FinalOutput);
        if (y != 0) {
            out.setText("Division is= " + (x / y));
        } else {
            out.setText("Division by zero is not allowed.");
        }
    }
}
